﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Net.Http;
using RouteAttribute = System.Web.Http.RouteAttribute;
using HttpPostAttribute = System.Web.Http.HttpPostAttribute;
using System.Net;

namespace Theatre.WebApi.Controllers
{
    public class TheatreTickets
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public int BoughtNumber { get; set; }
        public int SpentMoney { get; set; }
    }

    public class TheatreController : ApiController
    {
        public List<TheatreTickets> Customers = new List<TheatreTickets>
    {
        new TheatreTickets { Id = 1, Name = "Ivan", Surname = "Ivic", BoughtNumber = 5, SpentMoney = 50 },
        new TheatreTickets { Id = 2, Name = "Josip", Surname = "Josic", BoughtNumber = 6, SpentMoney = 60 },
        new TheatreTickets { Id = 3, Name = "Luka", Surname = "Vucemilovic", BoughtNumber = 7, SpentMoney = 70 },
        new TheatreTickets { Id = 4, Name = "Krunoslav", Surname = "Skoro", BoughtNumber = 2, SpentMoney = 10 },
        new TheatreTickets { Id = 5, Name = "Jusuf", Surname = "Begovic", BoughtNumber = 3, SpentMoney = 30 }
    };

        // GET api/Theatre

        public HttpResponseMessage Get()
        {
            return Request.CreateResponse(HttpStatusCode.OK, Customers);
        }

        // GET api/Theatre/Number Desired
        public HttpResponseMessage Get(int id)
        {
            var TheatreCustomer = Customers.FirstOrDefault(x => x.Id == id);
            if (TheatreCustomer == null)
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Customer Not Found!");
            }
            return Request.CreateResponse(HttpStatusCode.OK, TheatreCustomer);
        }

        // POST api/Theatre
        public HttpResponseMessage Post([FromBody] TheatreTickets theatreTickets)
        {
            var valuedCustomer = Customers.FirstOrDefault(x => x.Id == theatreTickets.Id);
            if (valuedCustomer == null)
            {
                Customers.Add(theatreTickets);
                return Request.CreateResponse(HttpStatusCode.OK, Customers);
            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Customer is not in database!");
            }
        }

        // PUT api/Theatre/5
        public List<TheatreTickets> Put(int id, [FromBody] TheatreTickets customer)
        {
            int index = Customers.FindIndex(x => x.Id == id);
            if (index >= 0)
            {
                Customers[index] = customer;
            }
            return Customers;
        }

        // DELETE api/Theatre/5
        public List<TheatreTickets> Delete(int id)
        {
            var customerToRemove = Customers.FirstOrDefault(x => x.Id == id);
            if (customerToRemove != null)
            {
                Customers.Remove(customerToRemove);
            }
            return Customers;
        }

    }
}
